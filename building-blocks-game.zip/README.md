
# Building Blocks Game

A simple building blocks game using Pygame where players can stack blocks by pressing the SPACE bar.

## How to Play
Press the `SPACE` key to stack blocks. Try to stack as many blocks as possible!

## Requirements
- Python 3.x
- Pygame library

## Installation
Install Pygame with:
```bash
pip install pygame
```

## Run the Game
Run the game with:
```bash
python main.py
```

## License
This project is open-source and free to use.
