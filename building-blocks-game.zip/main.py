
import pygame
import sys

# Initialize Pygame
pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Building Blocks Game")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Load block image
block_img = pygame.image.load("assets/block.png").convert_alpha()
block_rect = block_img.get_rect(center=(WIDTH // 2, HEIGHT // 2))

# Game variables
block_height = 50
block_positions = []  # List to store block positions
block_y = HEIGHT - block_height  # Starting y position for blocks
stack_height = 0  # Keeps track of current stack height

# Game loop
clock = pygame.time.Clock()
running = True
while running:
    screen.fill(WHITE)

    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                # Add a new block to the stack
                block_positions.append((WIDTH // 2, block_y - stack_height))
                stack_height += block_height

    # Draw the stacked blocks
    for pos in block_positions:
        screen.blit(block_img, pos)

    # Draw instructions
    font = pygame.font.Font(None, 36)
    instructions = font.render("Press SPACE to stack blocks", True, BLACK)
    screen.blit(instructions, (20, 20))

    # Update display
    pygame.display.flip()
    clock.tick(30)

pygame.quit()
sys.exit()
